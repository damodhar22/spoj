package com.he.ecommerce.entity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

public class Category {
    private Long id;
    
    private String name;

    public Category() {
    }

    public Category(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public boolean equals(Object object) {
		if(!object.getClass().equals(this.getClass()))
			return false;
		Category category = (Category) object;
		return category.id.equals(id)&&
				category.name.equals(name);
    	
    }
    
    @Override
    public int hashCode() {
    	return id.hashCode() + 
    			name.hashCode();
    }
    
}
