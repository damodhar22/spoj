package com.he.ecommerce.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

public class Coupon {
    private Long id;
    
    private String code;
    
    private Category category;
    
    private Double percent;
    
    private Double upperLimit;

    public Coupon() {
    }

    public Coupon(String code, Category category, Double percent, Double upperLimit) {
        this.code = code;
        this.category = category;
        this.percent = percent;
        this.upperLimit = upperLimit;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Double getPercent() {
        return percent;
    }

    public void setPercent(Double percent) {
        this.percent = percent;
    }

    public Double getUpperLimit() {
        return upperLimit;
    }

    public void setUpperLimit(Double upperLimit) {
        this.upperLimit = upperLimit;
    }
    @Override
    public boolean equals(Object object) {
    	if(!object.getClass().equals(this.getClass())) {
    		return false;
    	}
    	Coupon coupon = (Coupon)object;
    	return coupon.id.equals(id)&&
    			coupon.code.equals(code)&&
    			coupon.category.equals(category)&&
    			coupon.percent.equals(percent)&&
    			coupon.upperLimit.equals(upperLimit);
    }
    
    @Override
    public int hashCode() {
    	return id.hashCode() + 
    			code.hashCode() + 
    			category.hashCode() + 
    			percent.hashCode() + 
    			upperLimit.hashCode();
    }
}
