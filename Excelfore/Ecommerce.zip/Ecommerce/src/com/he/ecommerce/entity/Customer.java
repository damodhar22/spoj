package com.he.ecommerce.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

public class Customer {
    
    private Long id;

    private String username;
    private String hash;
    
    private String firstName;
    private String lastName;
    private String address;

    public Customer(String username, String hash, String firstName, String lastName, String address) {
        this.username = username;
        this.hash = hash;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
    }

    public Customer() {
        
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    @Override
    public boolean equals(Object object) {
    	if(!object.getClass().equals(this.getClass()))
    		return false;
    	Customer customer = (Customer)object;
    	return customer.id.equals(id)&&
    			customer.username.equals(username)&&
    			customer.firstName.equals(firstName)&&
    			customer.hash.equals(hash)&&
    			customer.lastName.equals(lastName)&&
    			customer.address.equals(address);
    }
    
        
}
