package com.he.ecommerce.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@NamedQueries({
    // TODO          
    // @NamedNativeQuery(name="getRevenue",
    //             query=""),
    
    //TODO
    // @NamedNativeQuery(name="getRevenueByCategory",
    //             query="select * from Category where category.id = ?1"),
    
    //TODO
    // @NamedNativeQuery(name="getRevenueByProduct",
    //             query="select * from Product where product.id = ?1"),
    
    //TODO
    //@NamedNativeQuery(name="getMostOrderedProductByCustomer",
    //             query="select * from Customer where customer.id = ?1"),
})
public class Product {
    
    private Long id;
    private String name;
    private Double price;
    
    private Category category;

    public Product() {
        
    }

    public Product(String name, Double price, Category category) {
        this.name = name;
        this.price = price;
        this.category = category; 
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    
    @Override
    public boolean equals(Object object) {
		if(!object.getClass().equals((this.getClass()))) {
			return false;
		}
		Product product = (Product)object;
		return product.name.equals(name)&&
				product.id.equals(id)&&
				product.price.equals(price)&&
				product.category.equals(category);
    	
    }
    
    @Override
	public int hashCode() {
    	return id.hashCode() + 
    			name.hashCode() + 
    			price.hashCode() + 
    			category.hashCode();
    }
    
    @Override
    public String toString(){
        return getId() +" "+ getName() +" "+  getPrice() +" "+  getCategory().getName();
    }
}
