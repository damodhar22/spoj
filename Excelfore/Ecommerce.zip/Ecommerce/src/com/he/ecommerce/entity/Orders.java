package com.he.ecommerce.entity;

import java.util.HashMap;
import java.util.Map;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyJoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Transient;

public class Orders {

	private Long id;
    
    private Coupon coupon;
    
    private Customer customer;

    private Map<Product, Integer> products = new HashMap<>();
    
    // this field is not stored in database
    private Double amount;

    // this field is not stored in database
    private Double discount;
    
    public Orders() {
    }

    public Orders(Coupon coupon, Customer customer, Map<Product, Integer> products) {
        this.coupon = coupon;
        this.customer = customer;
        this.products = products;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Map<Product, Integer> getProducts() {
        return products;
    }

    public void setProducts(Map<Product, Integer> products) {
        this.products = products;
    }

    public void addProduct(Product product, Integer quantity){
        if(this.products == null){
            this.products = new HashMap<>();
        }
        this.products.put(product, quantity);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Coupon getCoupon() {
        return coupon;
    }

    public void setCoupon(Coupon coupon) {
        this.coupon = coupon;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    
    @Override
    public boolean equals(Object object) {
    	if(!object.getClass().equals(this.getClass())){
    		return false;
    	}
    	Orders orders = (Orders)object;
    	return orders.id.equals(id)&&
    			orders.coupon.equals(coupon)&&
    			orders.customer.equals(customer);
    }
    
    @Override
    public int hashCode() {
    	return id.hashCode() +
    			coupon.hashCode() +
    			customer.hashCode();
    }
    
}
