package com.he.ecommerce.servlet;

import com.he.ecommerce.entity.Coupon;
import com.he.ecommerce.entity.Product;
import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "ListProductServlet", urlPatterns = {"/products"})
public class ProductServlet extends HttpServlet {

    @PersistenceUnit
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("user");
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        if(){ // Not logged in
//            response.sendRedirect("/login");
//        } else { // Logged in. refer to products.jsp to check which attributes to set
//        	request.getRequestDispatcher("/WEB-INF/jsp/products.jsp").forward(request, response);
//        }
    }


  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String code = request.getParameter("coupon");
        Coupon coupon = null;
        Map<Product, Integer> products = new HashMap<>();
        Double subTotal = 0.0;
        Double discount = 0.0;
        Double total = 0.0;
        
        // calculations
        //TODO
        
        request.setAttribute("coupon", code);
        request.setAttribute("subTotal", subTotal);
        request.setAttribute("discount", discount);
        request.setAttribute("total", total);
        request.setAttribute("map", products);
        request.getRequestDispatcher("/WEB-INF/jsp/checkout.jsp").forward(request, response);
        
    }

}
