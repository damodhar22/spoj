package com.he.ecommerce.servlet;

import com.he.ecommerce.Encryption;
import com.he.ecommerce.entity.Customer;
import java.io.IOException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    @PersistenceUnit
    private EntityManagerFactory emf;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    		//TODO
//        if(){  // Not Logged in
//            request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request, response);
//        } else { // Already logged in
//            response.sendRedirect("/");
//        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String conformation = request.getParameter("confirmation");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String address = request.getParameter("address");
        // form validation and inserting details in database
        // passwords are stored as hash values
        //TODO
    }
}
